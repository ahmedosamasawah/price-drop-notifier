const params = new URLSearchParams(location.search)

const product = {
  name: params.get('name') || '',
  price: params.get('price') || '',
  url: params.get('url') || ''
}

const el = document.getElementById('pdw')

if (el && window.PriceDropWidget?.mount) {
  el.addEventListener('pdw:subscribed', () => {
    parent.postMessage({ type: 'pdw:subscribed', url: product.url }, '*')
  })

  window.PriceDropWidget.mount({
    target: el,
    product,
    apiBaseUrl: '',
    assetBaseUrl: '/assets/'
  })
}
