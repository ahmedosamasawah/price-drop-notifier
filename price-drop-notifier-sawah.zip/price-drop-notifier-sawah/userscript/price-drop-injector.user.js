// ==UserScript==
// @name         Price-Drop Notifier Injector
// @namespace    https://localhost/
// @version      0.1.0
// @description  Injects a price-drop email widget on Amazon and eBay product pages.
// @match        https://www.amazon.com/*
// @match        https://www.ebay.com/*
// @include      https://*.amazon.*/*
// @include      https://*.ebay.*/*
// @run-at       document-idle
// ==/UserScript==

;(function () {
  'use strict'

  const ORIGIN = 'https://<your-public-https-origin>'
  const ORIGIN_NORM = ORIGIN.replace(/\/$/, '')
  const KEY_PREFIX = 'pdw_subscribed:'

  if (!ORIGIN_NORM.startsWith('https://') || ORIGIN_NORM.includes('<')) {
    console.warn('[pdw] Set ORIGIN in the userscript to your tunnel/deployed https:// domain.')
    return
  }

  if (!isLikelyProductPage(location.hostname, location.pathname)) return

  const product = extractProduct(location.hostname)
  if (!product || !product.url) return

  const normalizedUrl = normalizeUrl(product.url)
  if (normalizedUrl && safeGet(KEY_PREFIX + normalizedUrl)) {
    insertSubscribedNote(product)
    return
  }

  const container = insertContainer(location.hostname)
  if (!container) return

  container.id = `pdw_${Date.now()}_${Math.random().toString(16).slice(2)}`
  container.style.minHeight = '88px'

  container.addEventListener('pdw:style-error', () => {
    fallbackToIframe(container, product)
  })

  window.addEventListener('message', (ev) => {
    if (ev.origin !== ORIGIN_NORM) return
    const d = ev.data
    if (!d || d.type !== 'pdw:subscribed' || !d.url) return

    const u = normalizeUrl(String(d.url))
    if (u) safeSet(KEY_PREFIX + u, Date.now().toString())
  })

  loadScript(`${ORIGIN_NORM}/assets/price-drop-widget.umd.min.js`, 2000)
    .then(() => {
      const mounted = waitForMounted(container.id, 1500)

      window.postMessage(
        {
          source: 'pdw-userscript',
          type: 'pdw:mount',
          containerId: container.id,
          product,
          apiBaseUrl: ORIGIN_NORM,
          assetBaseUrl: `${ORIGIN_NORM}/assets/`
        },
        '*'
      )

      return mounted
    })
    .catch(() => {
      fallbackToIframe(container, product)
    })

  function extractProduct(hostname) {
    if (hostname.includes('amazon.')) {
      const name = txt(document.querySelector('#productTitle'))
      if (!name) return null

      const price =
        txt(document.querySelector('.a-price .a-offscreen')) ||
        txt(document.querySelector('#corePriceDisplay_desktop_feature_div .a-offscreen')) ||
        ''

      return { name, price, url: location.href }
    }

    if (hostname.includes('ebay.')) {
      const name =
        txt(document.querySelector('h1.x-item-title__mainTitle')) ||
        txt(document.querySelector('h1#itemTitle')) ||
        txt(document.querySelector('h1'))

      if (!name) return null

      const price =
        txt(document.querySelector('.x-price-primary span')) ||
        txt(document.querySelector('#prcIsum')) ||
        txt(document.querySelector('#mm-saleDscPrc')) ||
        ''

      return { name, price, url: location.href }
    }

    return null
  }

  function isLikelyProductPage(hostname, pathname) {
    if (hostname.includes('amazon.')) return pathname.includes('/dp/')
    if (hostname.includes('ebay.')) return pathname.includes('/itm/')
    return false
  }

  function insertContainer(hostname) {
    const existing = document.getElementById('pdw_userscript_container')
    if (existing) return existing.querySelector('[data-pdw-mount]') || null

    const outer = document.createElement('div')
    outer.id = 'pdw_userscript_container'

    const mount = document.createElement('div')
    mount.dataset.pdwMount = '1'
    outer.appendChild(mount)

    let anchor = null

    if (hostname.includes('amazon.')) {
      anchor =
        document.querySelector('#title_feature_div') ||
        document.querySelector('#titleSection') ||
        document.querySelector('#centerCol')
    } else if (hostname.includes('ebay.')) {
      anchor =
        document.querySelector('h1.x-item-title__mainTitle') ||
        document.querySelector('h1#itemTitle') ||
        document.querySelector('h1')
    }

    if (anchor && anchor.insertAdjacentElement) anchor.insertAdjacentElement('afterend', outer)
    else (document.body || document.documentElement).prepend(outer)

    return mount
  }

  function insertSubscribedNote(product) {
    const c = insertContainer(location.hostname)
    if (c) c.textContent = 'Subscribed for this product.'
  }

  function fallbackToIframe(container, product) {
    const outer = container && container.parentElement ? container.parentElement : container
    if (!outer || outer.dataset.pdwFallback) return
    outer.dataset.pdwFallback = '1'

    const src = `${ORIGIN_NORM}/embed/price-drop.html?name=${encodeURIComponent(
      product.name || ''
    )}&price=${encodeURIComponent(product.price || '')}&url=${encodeURIComponent(product.url || '')}`

    outer.textContent = ''

    const iframe = document.createElement('iframe')
    iframe.src = src
    iframe.width = '100%'
    iframe.height = '110'
    iframe.setAttribute('frameborder', '0')
    iframe.style.width = '100%'
    iframe.style.border = '0'
    iframe.style.minHeight = '110px'

    outer.appendChild(iframe)

    let loaded = false
    const t = setTimeout(() => {
      if (loaded) return
      outer.textContent = 'Widget unavailable.'
    }, 3500)

    iframe.addEventListener('load', () => {
      loaded = true
      clearTimeout(t)
    })
  }

  function loadScript(src, timeoutMs) {
    return new Promise((resolve, reject) => {
      const s = document.createElement('script')
      s.src = src
      s.async = true
      let done = false
      const t = setTimeout(() => {
        if (done) return
        done = true
        reject(new Error('script_load_timeout'))
      }, timeoutMs || 2000)

      s.onload = () => {
        if (done) return
        done = true
        clearTimeout(t)
        resolve(true)
      }
      s.onerror = () => {
        if (done) return
        done = true
        clearTimeout(t)
        reject(new Error('script_load_failed'))
      }
      ;(document.head || document.documentElement).appendChild(s)
    })
  }

  function safeGet(key) {
    try {
      return localStorage.getItem(key)
    } catch {
      return null
    }
  }

  function safeSet(key, value) {
    try {
      localStorage.setItem(key, value)
      return true
    } catch {
      return false
    }
  }

  function waitForMounted(containerId, timeoutMs) {
    return new Promise((resolve, reject) => {
      const t = setTimeout(() => {
        window.removeEventListener('message', onMsg)
        reject(new Error('mount_timeout'))
      }, timeoutMs)

      function onMsg(ev) {
        const d = ev.data
        if (!d || d.source !== 'pdw-widget' || d.type !== 'pdw:mounted') return
        if (d.containerId !== containerId) return
        clearTimeout(t)
        window.removeEventListener('message', onMsg)
        resolve(true)
      }

      window.addEventListener('message', onMsg)
    })
  }

  function normalizeUrl(url) {
    if (!url) return ''
    const h = url.indexOf('#')
    if (h !== -1) url = url.slice(0, h)
    const q = url.indexOf('?')
    if (q !== -1) url = url.slice(0, q)
    return url
  }

  function txt(el) {
    return (el && el.textContent ? el.textContent : '').replace(/\s+/g, ' ').trim()
  }
})()
