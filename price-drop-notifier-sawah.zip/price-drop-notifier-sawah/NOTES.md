# NOTES

## Userscript behavior (Amazon / eBay)
- Injection order: **script embed first**, then **iframe fallback** if CSP blocks script/styles.
- If both are blocked (e.g., `frame-src`), the userscript shows a short “Widget unavailable” message.

### Why the message bridge exists
Tampermonkey runs in a sandbox. Instead of relying on `unsafeWindow.PriceDropWidget`, the userscript requests mounting via `window.postMessage`, and the page-context widget listener performs the actual `PriceDropWidget.mount(...)` call.

## CSP / failure modes seen in the wild
- `script-src` blocks the widget bundle → iframe fallback is used.
- `style-src` blocks the widget stylesheet → the widget emits `pdw:style-error` → iframe fallback is used.
- `frame-src` / `X-Frame-Options` blocks the iframe → show “Widget unavailable”.

## Known limitations
- The current Amazon heuristic targets URLs containing `/dp/`. Pages using `/gp/product/...` may not trigger injection.
- Amazon/eBay DOM varies by locale/experiments; extraction selectors may fail on some variants.

## CSS collision observed + fix
**Observed:** Injecting plain `<input>/<button>` directly into Amazon/eBay pages caused typography and controls to be restyled by host CSS (font-size/line-height/padding/button gradients), leading to cramped/misaligned UI.

**Fix:** Render inside Shadow DOM + reset inherited styles with `:host { all: initial; ... }` and define explicit base typography in `widget/src/styles.css`.

## Proof / artifacts
Evidence files are included under `artifacts/`:
- Network Timing (waterfall) screenshot
- Network payload screenshot
- Lighthouse report
