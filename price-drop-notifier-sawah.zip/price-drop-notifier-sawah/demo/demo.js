const el = document.getElementById('pdw')

if (el && window.PriceDropWidget?.mount) {
  window.PriceDropWidget.mount({
    target: el,
    product: {
      name: 'Demo Product',
      price: 'USD 129.99',
      url: location.href
    },
    apiBaseUrl: '',
    assetBaseUrl: '/assets/'
  })
}
