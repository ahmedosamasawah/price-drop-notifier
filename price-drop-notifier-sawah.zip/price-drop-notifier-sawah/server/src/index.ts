import express from 'express'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const app = express()

app.use((req, res, next) => {
  const start = Date.now()
  res.on('finish', () => {
    const ms = Date.now() - start
    console.log(`${req.method} ${req.originalUrl} ${res.statusCode} ${ms}ms`)
  })
  next()
})

app.use(express.json({ limit: '64kb' }))
app.use(express.urlencoded({ extended: true }))

app.options('/subscribe-price-drop', (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*')
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS')
  res.setHeader('Access-Control-Allow-Headers', 'content-type')
  res.status(204).end()
})

const subscribed = new Set<string>()

app.post('/subscribe-price-drop', (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*')

  const body = (req.body || {}) as any
  const email = String(body.email || '').trim()

  const p = body.product || {}
  const name = String(p.name || body.name || '').trim()
  const price = String(p.price || body.price || '').trim()
  const url = String(p.url || body.url || '').trim()
  const normalizedUrl = normalizeProductUrl(url)

  const delay = randInt(800, 2800)

  setTimeout(() => {
    if (!isValidEmail(email)) {
      res.status(400).json({ ok: false, error: 'invalid_email' })
      return
    }

    const key = `${email.toLowerCase()}::${normalizedUrl}`
    if (normalizedUrl && subscribed.has(key)) {
      res.status(409).json({ ok: false, error: 'already_subscribed' })
      return
    }

    if (Math.random() < 0.08) {
      res.status(503).json({ ok: false, error: 'server_error' })
      return
    }

    if (normalizedUrl) subscribed.add(key)

    res.status(200).json({ ok: true })
  }, delay)
})

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const rootDir = path.resolve(__dirname, '../..')

app.use(
  '/assets',
  express.static(path.join(rootDir, 'widget', 'dist'), {
    setHeaders(res) {
      res.setHeader('Cache-Control', 'public, max-age=86400')
    }
  })
)

app.use('/embed', express.static(path.join(rootDir, 'embed')))

const demoDir = path.join(rootDir, 'demo')

const demoCsp =
  "default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'none'"

app.get(['/demo', '/demo/', '/demo/index.html'], (req, res) => {
  res.setHeader('Content-Security-Policy', demoCsp)
  res.sendFile(path.join(demoDir, 'index.html'))
})

app.use('/demo', express.static(demoDir, { index: false }))

app.get('/', (req, res) => {
  res.redirect('/demo/')
})

const port = Number(process.env.PORT || 3000)
app.listen(port, () => {
  console.log(`listening on http://localhost:${port}`)
})

function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
}

function normalizeProductUrl(url: string): string {
  if (!url) return ''
  const h = url.indexOf('#')
  if (h !== -1) url = url.slice(0, h)
  const q = url.indexOf('?')
  if (q !== -1) url = url.slice(0, q)
  return url
}

function randInt(min: number, max: number): number {
  return Math.floor(min + Math.random() * (max - min + 1))
}
