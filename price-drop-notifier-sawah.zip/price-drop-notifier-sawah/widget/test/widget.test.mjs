import test from 'node:test'
import assert from 'node:assert/strict'
import http from 'node:http'

import {
  extractProduct,
  fetchWithTimeout,
  isValidEmail,
  normalizeProductUrl
} from '../dist/price-drop-widget.esm.js'

test('isValidEmail', () => {
  assert.equal(isValidEmail('a@b.co'), true)
  assert.equal(isValidEmail('a@b'), false)
  assert.equal(isValidEmail('a'), false)
  assert.equal(isValidEmail('a@'), false)
})

test('normalizeProductUrl', () => {
  assert.equal(normalizeProductUrl('https://e.com/p?a=1#x'), 'https://e.com/p')
  assert.equal(normalizeProductUrl('https://e.com/p#x'), 'https://e.com/p')
  assert.equal(normalizeProductUrl('https://e.com/p?a=1'), 'https://e.com/p')
})

test('extractProduct (Amazon-ish)', async () => {
  const { parseHTML } = await import('linkedom')
  const { document } = parseHTML(
    '<html><head><title>T</title></head><body><span id="productTitle">Widget 3000</span><span class="a-price"><span class="a-offscreen">$129.99</span></span></body></html>'
  )

  const p = extractProduct(document)
  assert.equal(p.name, 'Widget 3000')
  assert.equal(p.price, '$129.99')
})

test('extractProduct (eBay-ish)', async () => {
  const { parseHTML } = await import('linkedom')
  const { document } = parseHTML(
    '<html><head></head><body><h1 class="x-item-title__mainTitle">Thing</h1><div class="x-price-primary"><span>US $9.99</span></div></body></html>'
  )

  const p = extractProduct(document)
  assert.equal(p.name, 'Thing')
  assert.equal(p.price, 'US $9.99')
})

test('fetchWithTimeout aborts', async () => {
  const server = http.createServer((req, res) => {
    setTimeout(() => {
      res.writeHead(200, { 'content-type': 'application/json' })
      res.end(JSON.stringify({ ok: true }))
    }, 200)
  })

  await new Promise((resolve) => server.listen(0, resolve))

  const addr = server.address()
  const port = typeof addr === 'object' && addr ? addr.port : 0
  const url = `http://127.0.0.1:${port}/slow`

  await assert.rejects(
    fetchWithTimeout(url, { method: 'GET' }, 30),
    (err) => err && err.name === 'AbortError'
  )

  server.close()
})
