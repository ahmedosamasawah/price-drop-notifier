export type Product = {
  name: string
  price: string
  url: string
}

export type MountOptions = {
  target: HTMLElement | string
  product?: Partial<Product>
  apiBaseUrl?: string
  assetBaseUrl?: string
  storageKeyPrefix?: string
}

export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
}

export function normalizeProductUrl(url: string): string {
  if (!url) return ''
  const h = url.indexOf('#')
  if (h !== -1) url = url.slice(0, h)
  const q = url.indexOf('?')
  if (q !== -1) url = url.slice(0, q)
  return url
}

export function extractProduct(doc: Document): Product {
  const url = normalizeProductUrl(doc.URL || '')

  const name =
    text(doc.querySelector('#productTitle')) ||
    text(doc.querySelector('h1.x-item-title__mainTitle')) ||
    text(doc.querySelector('h1#itemTitle')) ||
    meta(doc, 'property', 'og:title') ||
    (doc.title || '')

  const price =
    text(doc.querySelector('.a-price .a-offscreen')) ||
    text(doc.querySelector('.x-price-primary span')) ||
    text(doc.querySelector('.x-price-primary')) ||
    meta(doc, 'property', 'product:price:amount') ||
    ''

  return {
    name: (name || '').trim(),
    price: (price || '').trim(),
    url: (url || '').trim()
  }
}

export function fetchWithTimeout(input: RequestInfo | URL, init: RequestInit, timeoutMs: number) {
  const controller = new AbortController()
  const t = setTimeout(() => controller.abort(), timeoutMs)
  return fetch(input, { ...init, signal: controller.signal }).finally(() => clearTimeout(t))
}

export function mount(options: MountOptions) {
  const host = resolveTarget(options.target)
  if (!host) return

  const storageKeyPrefix = options.storageKeyPrefix || 'pdw_subscribed:'
  const extracted = extractProduct(document)

  const product: Product = {
    name: (options.product?.name ?? extracted.name ?? '').toString().trim(),
    price: (options.product?.price ?? extracted.price ?? '').toString().trim(),
    url: (options.product?.url ?? extracted.url ?? normalizeProductUrl(location.href) ?? '').toString().trim()
  }

  const normalizedUrl = normalizeProductUrl(product.url)
  const storageKey = normalizedUrl ? `${storageKeyPrefix}${normalizedUrl}` : ''
  const already = storageKey ? safeLsGet(storageKey) : null

  host.textContent = ''
  host.style.visibility = 'hidden'

  const shadow = host.shadowRoot || host.attachShadow({ mode: 'open' })
  shadow.textContent = ''

  const assetBaseUrl = ensureSlash(options.assetBaseUrl || detectAssetBaseUrl() || '/assets/')
  const cssHref = new URL('price-drop-widget.css', resolveBaseUrl(assetBaseUrl)).toString()

  const css = document.createElement('link')
  css.rel = 'stylesheet'
  css.href = cssHref

  let cssSettled = false
  const cssTimer = setTimeout(() => {
    if (cssSettled) return
    cssSettled = true
    host.style.visibility = ''
    host.dispatchEvent(new CustomEvent('pdw:style-error', { bubbles: true, composed: true }))
  }, 1200)

  css.onload = () => {
    if (cssSettled) return
    cssSettled = true
    clearTimeout(cssTimer)
    host.style.visibility = ''
  }

  css.onerror = () => {
    if (cssSettled) return
    cssSettled = true
    clearTimeout(cssTimer)
    host.style.visibility = ''
    host.dispatchEvent(new CustomEvent('pdw:style-error', { bubbles: true, composed: true }))
  }

  shadow.appendChild(css)

  const wrap = document.createElement('div')
  wrap.className = 'pdw'
  shadow.appendChild(wrap)

  const title = document.createElement('div')
  title.className = 'pdw__title'
  title.textContent = 'Email me if this product gets cheaper'
  wrap.appendChild(title)

  const sub = document.createElement('div')
  sub.className = 'pdw__sub'
  sub.textContent = product.name ? product.name : 'Price-drop alerts'
  wrap.appendChild(sub)

  const form = document.createElement('form')
  form.setAttribute('novalidate', 'novalidate')
  wrap.appendChild(form)

  const row = document.createElement('div')
  row.className = 'pdw__row'
  form.appendChild(row)

  const input = document.createElement('input')
  input.className = 'pdw__email'
  input.type = 'email'
  input.inputMode = 'email'
  input.autocomplete = 'email'
  input.placeholder = 'you@example.com'
  input.required = true
  row.appendChild(input)

  const btn = document.createElement('button')
  btn.className = 'pdw__btn'
  btn.type = 'submit'
  btn.textContent = 'Notify me'
  row.appendChild(btn)

  const status = document.createElement('div')
  status.className = 'pdw__status'
  status.setAttribute('aria-live', 'polite')
  wrap.appendChild(status)

  function setDisabled(disabled: boolean) {
    input.disabled = disabled
    btn.disabled = disabled
  }

  function setStatus(msg: string) {
    status.textContent = msg
  }

  function shake() {
    wrap.classList.remove('pdw--error')
    void wrap.offsetWidth
    wrap.classList.add('pdw--error')
  }

  function markSubscribed() {
    if (storageKey) safeLsSet(storageKey, Date.now().toString())
    host.dispatchEvent(new CustomEvent('pdw:subscribed', { bubbles: true, composed: true, detail: { url: product.url } }))
  }

  if (already) {
    setDisabled(true)
    setStatus('Subscribed for this product.')
    host.style.visibility = ''
    return
  }

  setStatus('')

  form.addEventListener('submit', (e) => {
    e.preventDefault()

    const email = input.value.trim()
    if (!isValidEmail(email)) {
      setStatus('Please enter a valid email.')
      shake()
      return
    }

    const apiBase = (options.apiBaseUrl || '').replace(/\/$/, '')
    const url = apiBase ? `${apiBase}/subscribe-price-drop` : '/subscribe-price-drop'

    wrap.classList.add('pdw--submitting')
    setDisabled(true)
    setStatus('Submitting…')

    const body = JSON.stringify({ email, product })

    fetchWithTimeout(
      url,
      {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body
      },
      8000
    )
      .then((r) => r.json().then((j) => ({ r, j })))
      .then(({ r, j }) => {
        wrap.classList.remove('pdw--submitting')

        if (r.status === 200 && j?.ok) {
          markSubscribed()
          setStatus('Subscribed. We\'ll email you if it gets cheaper.')
          setDisabled(true)
          return
        }

        if (r.status === 409 && j?.error === 'already_subscribed') {
          markSubscribed()
          setStatus('Already subscribed for this product.')
          setDisabled(true)
          return
        }

        if (r.status === 400 && j?.error === 'invalid_email') {
          setStatus('Please enter a valid email.')
          setDisabled(false)
          shake()
          return
        }

        setStatus('Something went wrong. Try again.')
        setDisabled(false)
        shake()
      })
      .catch((err) => {
        wrap.classList.remove('pdw--submitting')
        setDisabled(false)

        if (err?.name === 'AbortError') setStatus('Request timed out. Try again.')
        else setStatus('Network error. Try again.')

        shake()
      })
  })
}

const BRIDGE_SOURCE = 'pdw-userscript'

if (typeof window !== 'undefined') {
  window.addEventListener('message', (ev) => {
    const d = (ev as MessageEvent).data
    if (!d || d.source !== BRIDGE_SOURCE || d.type !== 'pdw:mount') return

    const containerId = String(d.containerId || '')
    if (!containerId) return

    const el = document.getElementById(containerId)
    if (!el) return

    mount({
      target: el,
      product: d.product || {},
      apiBaseUrl: typeof d.apiBaseUrl === 'string' ? d.apiBaseUrl : '',
      assetBaseUrl: typeof d.assetBaseUrl === 'string' ? d.assetBaseUrl : ''
    })

    window.postMessage({ source: 'pdw-widget', type: 'pdw:mounted', containerId }, '*')
  })
}

function resolveTarget(target: HTMLElement | string): HTMLElement | null {
  if (typeof target === 'string') return document.querySelector(target)
  return target
}

function text(el: Element | null): string {
  return (el?.textContent || '').replace(/\s+/g, ' ').trim()
}

function meta(doc: Document, attr: string, attrValue: string): string {
  const el = doc.querySelector(`meta[${attr}="${attrValue}"]`)
  return (el && (el as HTMLMetaElement).content) || ''
}

function ensureSlash(s: string): string {
  return s.endsWith('/') ? s : `${s}/`
}

function safeLsGet(key: string): string | null {
  if (!key) return null
  try {
    return window.localStorage.getItem(key)
  } catch {
    return null
  }
}

function safeLsSet(key: string, value: string): boolean {
  if (!key) return false
  try {
    window.localStorage.setItem(key, value)
    return true
  } catch {
    return false
  }
}

function resolveBaseUrl(base: string): string {
  try {
    return new URL(base).toString()
  } catch {
    return new URL(base, document.baseURI).toString()
  }
}

function detectAssetBaseUrl(): string {
  const scripts = Array.from(document.querySelectorAll('script[src]'))
  const srcs = scripts.map((s) => (s as HTMLScriptElement).src).filter(Boolean)
  let hit = ''
  for (let i = srcs.length - 1; i >= 0; i--) {
    const src = srcs[i]
    if (src.includes('price-drop-widget')) {
      hit = src
      break
    }
  }

  if (!hit) return ''
  const i = hit.lastIndexOf('/')
  if (i === -1) return ''
  return hit.slice(0, i + 1)
}
