import esbuild from 'esbuild'
import fs from 'node:fs'

const watch = process.argv.includes('--watch')
const watchOptions = watch
  ? {
      watch: {
        onRebuild(error) {
          if (error) console.error('[widget] rebuild failed')
          else console.log('[widget] rebuilt')
        }
      }
    }
  : {}

const common = {
  bundle: true,
  sourcemap: true,
  target: ['es2020']
}

await esbuild.build({
  ...common,
  entryPoints: ['widget/src/index.ts'],
  outfile: 'widget/dist/price-drop-widget.umd.min.js',
  format: 'iife',
  globalName: 'PriceDropWidget',
  minify: true,
  legalComments: 'none',
  ...watchOptions
})

fs.copyFileSync('widget/dist/price-drop-widget.umd.min.js', 'widget/dist/price-drop-widget.min.js')

await esbuild.build({
  ...common,
  entryPoints: ['widget/src/index.ts'],
  outfile: 'widget/dist/price-drop-widget.esm.js',
  format: 'esm',
  minify: false,
  ...watchOptions
})

await esbuild.build({
  entryPoints: ['widget/src/widget.css'],
  outfile: 'widget/dist/price-drop-widget.css',
  bundle: true,
  minify: true,
  sourcemap: true,
  ...watchOptions
})
